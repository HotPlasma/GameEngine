#ifndef __CLSTUFF_HDR__
#define __CLSTUFF_HDR__





void initCL(void);

#endif //__CLSTUFF_HDR__